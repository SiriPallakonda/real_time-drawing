
import type { User, DrawOperation, Point, ToolOptions } from '../types';

type Listener = (data: any) => void;
type EventListeners = { [event: string]: Listener[] };

const NAMES = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank'];
const COLORS = ['#EF4444', '#F97316', '#84CC16', '#22C55E', '#0EA5E9', '#A855F7'];

class MockSocketService {
  private listeners: EventListeners = {};
  private users: User[] = [];
  private operationHistory: DrawOperation[] = [];
  private redoStack: DrawOperation[] = [];
  private self: User | null = null;
  private otherUserIntervals: number[] = [];
  private drawingOps: { [userId: string]: DrawOperation } = {};

  constructor() {
    this.connect();
  }

  private connect() {
    // Simulate self connection
    const id = `user-${Math.random().toString(36).substr(2, 9)}`;
    const name = `User-${id.substring(0, 4)}`;
    this.self = { id, name, color: '#FFFFFF' };
    this.users.push(this.self);
    this.broadcast('users', this.users);
    
    // Simulate other users joining
    for (let i = 0; i < 3; i++) {
        setTimeout(() => this.addOtherUser(), 1000 + i * 500);
    }
  }

  private addOtherUser() {
    if (this.users.length >= NAMES.length) return;
    const id = `user-${Math.random().toString(36).substr(2, 9)}`;
    const name = NAMES[this.users.length];
    const color = COLORS[this.users.length % COLORS.length];
    const user = { id, name, color };
    this.users.push(user);
    this.broadcast('users', this.users);
    this.startSimulatingUser(user);
  }

  private startSimulatingUser(user: User) {
    const interval = window.setInterval(() => {
        const shouldDraw = Math.random() > 0.5;
        if (shouldDraw) {
            this.simulateDrawing(user);
        } else {
             this.simulateCursorMove(user);
        }
    }, 2000 + Math.random() * 3000);
    this.otherUserIntervals.push(interval);
  }

  private simulateCursorMove(user: User) {
    const cursor = { x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight };
    const userIndex = this.users.findIndex(u => u.id === user.id);
    if(userIndex !== -1) {
        this.users[userIndex].cursor = cursor;
        this.broadcast('users', this.users);
    }
  }

  private simulateDrawing(user: User) {
    const startPoint = { x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight };
    const op: DrawOperation = {
        id: `${user.id}-${Date.now()}`,
        userId: user.id,
        options: { tool: 'brush', color: user.color, lineWidth: Math.ceil(Math.random() * 10) + 2 },
        points: [startPoint]
    };
    this.handleDrawStart(op);

    let pointsDrawn = 0;
    const drawInterval = setInterval(() => {
        if(pointsDrawn > 10 + Math.random() * 20) {
            clearInterval(drawInterval);
            this.handleDrawEnd(op);
            return;
        }
        const lastPoint = op.points[op.points.length - 1];
        const nextPoint = { 
            x: lastPoint.x + (Math.random() - 0.5) * 30,
            y: lastPoint.y + (Math.random() - 0.5) * 30,
        };
        op.points.push(nextPoint);
        this.handleDrawMove(op);
        pointsDrawn++;
    }, 50);
  }

  on(event: string, listener: Listener) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(listener);
  }

  emit(event: string, data: any) {
    // Simulate network delay
    setTimeout(() => {
      switch (event) {
        case 'draw-start':
          this.handleDrawStart(data as DrawOperation);
          break;
        case 'draw-move':
          this.handleDrawMove(data as DrawOperation);
          break;
        case 'draw-end':
          this.handleDrawEnd(data as DrawOperation);
          break;
        case 'cursor-move':
          this.handleCursorMove(data as Point);
          break;
        case 'undo':
          this.handleUndo();
          break;
        case 'redo':
          this.handleRedo();
          break;
      }
    }, 50);
  }
  
  private broadcast(event: string, data: any) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(listener => listener(data));
    }
  }
  
  private handleDrawStart(op: DrawOperation) {
    this.drawingOps[op.userId] = op;
    this.broadcast('drawing-ops', this.drawingOps);
  }
  
  private handleDrawMove(op: DrawOperation) {
    this.drawingOps[op.userId] = op;
    this.broadcast('drawing-ops', this.drawingOps);
  }

  private handleDrawEnd(op: DrawOperation) {
    this.operationHistory.push(op);
    this.redoStack = [];
    delete this.drawingOps[op.userId];
    this.broadcast('drawing-ops', this.drawingOps);
    this.broadcast('history', { history: this.operationHistory, redoStack: this.redoStack });
  }
  
  private handleCursorMove(pos: Point) {
    if(!this.self) return;
    const userIndex = this.users.findIndex(u => u.id === this.self!.id);
    if(userIndex !== -1) {
        this.users[userIndex].cursor = pos;
        this.broadcast('users', [...this.users]);
    }
  }

  private handleUndo() {
    if (this.operationHistory.length === 0) return;
    const lastOp = this.operationHistory.pop();
    if (lastOp) {
      this.redoStack.push(lastOp);
      this.broadcast('history', { history: this.operationHistory, redoStack: this.redoStack });
    }
  }

  private handleRedo() {
    if (this.redoStack.length === 0) return;
    const opToRedo = this.redoStack.pop();
    if (opToRedo) {
      this.operationHistory.push(opToRedo);
      this.broadcast('history', { history: this.operationHistory, redoStack: this.redoStack });
    }
  }
  
  getSelf = () => this.self;

  disconnect() {
    this.otherUserIntervals.forEach(clearInterval);
  }
}

export const socketService = new MockSocketService();
