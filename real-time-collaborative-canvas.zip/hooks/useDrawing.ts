import React, { useState, useCallback, useEffect } from 'react';
import type { DrawOperation, Point, ToolOptions } from '../types';
import { socketService } from '../services/socketService';

export const useDrawing = (toolOptions: ToolOptions) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentOperation, setCurrentOperation] = useState<DrawOperation | null>(null);

  const getPoint = (e: MouseEvent | TouchEvent): Point => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const handleStartDrawing = useCallback((e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setIsDrawing(true);
    const point = getPoint(e.nativeEvent);
    const newOp: DrawOperation = {
      id: `${socketService.getSelf()?.id}-${Date.now()}`,
      userId: socketService.getSelf()?.id ?? '',
      options: toolOptions,
      points: [point],
    };
    setCurrentOperation(newOp);
    socketService.emit('draw-start', newOp);
  }, [toolOptions]);

  const handleDraw = useCallback((e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!isDrawing || !currentOperation) return;

    const point = getPoint(e.nativeEvent);
    setCurrentOperation(prev => {
        if (!prev) return null;
        const updatedOp = { ...prev, points: [...prev.points, point] };
        socketService.emit('draw-move', updatedOp);
        return updatedOp;
    });
  }, [isDrawing, currentOperation]);

  const handleEndDrawing = useCallback(() => {
    if (!isDrawing || !currentOperation) return;
    setIsDrawing(false);
    if(currentOperation.points.length > 1) {
       socketService.emit('draw-end', currentOperation);
    }
    setCurrentOperation(null);
  }, [isDrawing, currentOperation]);
  
  const handleCursorMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
      const point = getPoint(e.nativeEvent);
      socketService.emit('cursor-move', point);
  }, []);

  useEffect(() => {
    const handleMouseUpOutside = () => {
      if (isDrawing) {
        handleEndDrawing();
      }
    };
    
    window.addEventListener('mouseup', handleMouseUpOutside);
    window.addEventListener('touchend', handleMouseUpOutside);

    return () => {
      window.removeEventListener('mouseup', handleMouseUpOutside);
      window.removeEventListener('touchend', handleMouseUpOutside);
    };
  }, [isDrawing, handleEndDrawing]);

  return {
    handleStartDrawing,
    handleDraw,
    handleEndDrawing,
    handleCursorMove,
    currentOperation,
  };
};