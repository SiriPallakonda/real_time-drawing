
import React from 'react';
import type { User } from '../types';

interface UserListProps {
  users: User[];
  selfId: string;
}

export const UserList: React.FC<UserListProps> = ({ users, selfId }) => {
  return (
    <div className="absolute top-4 right-4 bg-gray-800 p-3 rounded-lg shadow-2xl w-48 z-10">
      <h3 className="font-bold mb-2 text-center text-gray-300">Online Users</h3>
      <ul className="space-y-2">
        {users.map(user => (
          <li key={user.id} className="flex items-center">
            <div
              className="w-4 h-4 rounded-full mr-3 border-2 border-gray-900"
              style={{ backgroundColor: user.color }}
            />
            <span className="truncate text-sm font-medium">{user.name} {user.id === selfId && '(You)'}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};
