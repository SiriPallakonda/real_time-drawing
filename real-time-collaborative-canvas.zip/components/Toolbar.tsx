
import React from 'react';
import type { Tool, ToolOptions } from '../types';
import { BrushIcon, EraserIcon, UndoIcon, RedoIcon } from './icons';

interface ToolbarProps {
  toolOptions: ToolOptions;
  setToolOptions: React.Dispatch<React.SetStateAction<ToolOptions>>;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

const colors = [
  '#FFFFFF', '#EF4444', '#F97316', '#EAB308',
  '#84CC16', '#22C55E', '#14B8A6', '#0EA5E9',
  '#6366F1', '#A855F7', '#EC4899'
];

export const Toolbar: React.FC<ToolbarProps> = ({ toolOptions, setToolOptions, onUndo, onRedo, canUndo, canRedo }) => {
  const handleToolChange = (tool: Tool) => {
    setToolOptions(prev => ({ ...prev, tool }));
  };

  const handleColorChange = (color: string) => {
    setToolOptions(prev => ({ ...prev, color }));
  };

  const handleLineWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setToolOptions(prev => ({ ...prev, lineWidth: parseInt(e.target.value, 10) }));
  };

  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-gray-800 p-2 rounded-lg shadow-2xl flex items-center space-x-4 z-10">
      <div className="flex items-center space-x-1">
        <button
          onClick={() => handleToolChange('brush')}
          className={`p-2 rounded ${toolOptions.tool === 'brush' ? 'bg-sky-500' : 'hover:bg-gray-700'}`}
        >
          <BrushIcon className="w-6 h-6" />
        </button>
        <button
          onClick={() => handleToolChange('eraser')}
          className={`p-2 rounded ${toolOptions.tool === 'eraser' ? 'bg-sky-500' : 'hover:bg-gray-700'}`}
        >
          <EraserIcon className="w-6 h-6" />
        </button>
      </div>
      
      <div className="h-8 w-px bg-gray-600"></div>

      <div className="flex items-center space-x-2">
        {colors.map(color => (
          <button
            key={color}
            onClick={() => handleColorChange(color)}
            className={`w-6 h-6 rounded-full border-2 ${toolOptions.color === color ? 'border-sky-400' : 'border-transparent hover:border-gray-500'}`}
            style={{ backgroundColor: color }}
          />
        ))}
        <input
          type="color"
          value={toolOptions.color}
          onChange={(e) => handleColorChange(e.target.value)}
          className="w-8 h-8 p-0 border-none bg-transparent cursor-pointer"
        />
      </div>

      <div className="h-8 w-px bg-gray-600"></div>

      <div className="flex items-center space-x-2 text-sm">
        <span>Width: {toolOptions.lineWidth}</span>
        <input
          type="range"
          min="1"
          max="50"
          value={toolOptions.lineWidth}
          onChange={handleLineWidthChange}
          className="w-24 accent-sky-500"
        />
      </div>

      <div className="h-8 w-px bg-gray-600"></div>

      <div className="flex items-center space-x-1">
        <button onClick={onUndo} disabled={!canUndo} className="p-2 rounded hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed">
          <UndoIcon className="w-6 h-6" />
        </button>
        <button onClick={onRedo} disabled={!canRedo} className="p-2 rounded hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed">
          <RedoIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
