
import React, { useRef, useEffect } from 'react';
import type { User, DrawOperation } from '../types';

interface CanvasProps {
  operations: DrawOperation[];
  otherUsers: User[];
  onDraw: (op: DrawOperation) => void;
  onCursorMove: (pos: { x: number; y: number }) => void;
  currentOperation: DrawOperation | null;
}

const drawOperation = (ctx: CanvasRenderingContext2D, op: DrawOperation) => {
  const { options, points } = op;
  if (points.length < 2) return;

  ctx.globalCompositeOperation = options.tool === 'eraser' ? 'destination-out' : 'source-over';
  ctx.strokeStyle = options.color;
  ctx.lineWidth = options.lineWidth;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i].x, points[i].y);
  }
  ctx.stroke();
};

export const Canvas: React.FC<CanvasProps> = ({ operations, otherUsers, onDraw, onCursorMove, currentOperation }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const resizeCanvas = () => {
        const { width, height } = canvas.getBoundingClientRect();
        if (canvas.width !== width || canvas.height !== height) {
            canvas.width = width;
            canvas.height = height;
            redraw();
        }
    };

    const redraw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      operations.forEach(op => drawOperation(ctx, op));
      if (currentOperation) {
        drawOperation(ctx, currentOperation);
      }
    };
    
    redraw();
    
    const resizeObserver = new ResizeObserver(resizeCanvas);
    if(containerRef.current) {
        resizeObserver.observe(containerRef.current);
    }
    
    return () => {
        resizeObserver.disconnect();
    }
  }, [operations, currentOperation]);

  return (
    <div ref={containerRef} className="w-full h-full relative bg-gray-700 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full" />
      {otherUsers.map(user =>
        user.cursor ? (
          <div
            key={user.id}
            className="absolute w-3 h-3 rounded-full -translate-x-1/2 -translate-y-1/2 pointer-events-none"
            style={{
              left: `${user.cursor.x}px`,
              top: `${user.cursor.y}px`,
              backgroundColor: user.color,
            }}
          />
        ) : null
      )}
    </div>
  );
};
